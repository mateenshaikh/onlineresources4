---
description: |
  This is a plain page test, and the beginning of a YAML multiline description...
title: page X
weight: 1
---

This is a plain demo child page.
