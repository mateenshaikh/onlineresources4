---
descrption: Th' Attachments shorrrtcode displays a list o' files attached t' a plank
title: Attachments
---
{{% attachments /%}}

{{< piratify >}}