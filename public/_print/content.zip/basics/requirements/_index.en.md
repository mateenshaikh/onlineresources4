---
disableToc: true
title: Requirements
weight: 10
---

Thanks to the simplicity of Hugo, this page is as empty as this theme needs requirements.

Just download latest version of [Hugo binary](https://gohugo.io/getting-started/installing/) for your OS (Windows, Linux, Mac) : it's that simple.

![Magic](images/magic.gif?classes=shadow)
